#include "Sensors.h"

static Adafruit_TSL2561_Unified tsl = Adafruit_TSL2561_Unified(TSL2561_ADDR_FLOAT, 12345);
static Adafruit_HTU21DF htu = Adafruit_HTU21DF();
static SensorData sensors = {0, 0.0, 0, 0.0, 0, 0, 0};

void initializeSensors() {
  Wire.begin();
  
  Serial.print("Initializing TSL2561 light sensor... ");
  if (!tsl.begin()) {
    Serial.println("FAILED!");
    Serial.println("⚠️  No TSL2561 detected. Light readings will be 0.");
  } else {
    configureTSL2561();
    Serial.println("OK!");
  }

  Serial.print("Initializing HTU21D-F temp/humidity sensor... ");
  if (!htu.begin()) {
    Serial.println("FAILED!");
    Serial.println("⚠️  No HTU21D-F detected. Temp/humidity will be 0.");
  } else {
    Serial.println("OK!");
  }
}

void configureTSL2561() {
  tsl.setGain(TSL2561_GAIN_16X);
  tsl.setIntegrationTime(TSL2561_INTEGRATIONTIME_101MS);
}

void readEnvironmentalSensors() {
  float temp_c = htu.readTemperature();
  float humidity = htu.readHumidity();
  
  if (!isnan(temp_c) && temp_c >= -40 && temp_c <= 85) {
    sensors.temperature = (int)temp_c;
  }
  
  if (!isnan(humidity) && humidity >= 0 && humidity <= 100) {
    sensors.humidity = humidity;
  }
  
  sensors_event_t event;
  if (tsl.getEvent(&event)) {
    if (event.light > 0 && event.light < 100000) {
      sensors.lux = (int)event.light;
    }
  }
  
  sensors.lastEnvironmentalUpdate = millis();
}

SensorData& getSensorData() {
  return sensors;
}

void printCurrentSensorValues() {
  Serial.println("=== Current Sensor Values ===");
  Serial.print("Temperature: ");
  Serial.print(sensors.temperature);
  Serial.println("°C");
  Serial.print("Humidity: ");
  Serial.print(sensors.humidity, 1);
  Serial.println("%");
  Serial.print("Lux: ");
  Serial.println(sensors.lux);
  Serial.print("Distance: ");
  Serial.print(sensors.distance, 2);
  Serial.println(" in");
  Serial.println("============================\n");
}