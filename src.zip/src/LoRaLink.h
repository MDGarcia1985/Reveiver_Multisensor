#pragma once
#include <Arduino.h>
#include <SPI.h>
#include <LoRa.h>

#define LORA_TRANSMIT_INTERVAL 1000

#define LORA_SCK SCK
#define LORA_MISO MISO
#define LORA_MOSI MOSI
#define LORA_CS 12
#define LORA_RST 13
#define LORA_DIO0 11

bool initializeLoRa();
void createHub(const char* hubName, const char* sensorNames, const char* types);
void pushAllData(const char* hubName);
bool isLoRaActive();