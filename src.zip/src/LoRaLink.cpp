#include "LoRaLink.h"
#include "Sensors.h"

static bool loraActive = false;

bool initializeLoRa() {
  Serial.println("\n========== Initializing LoRa ==========");
  Serial.println("Pin Configuration:");
  Serial.print("  SCK:  GPIO "); Serial.println(LORA_SCK);
  Serial.print("  MISO: GPIO "); Serial.println(LORA_MISO);
  Serial.print("  MOSI: GPIO "); Serial.println(LORA_MOSI);
  Serial.print("  CS:   GPIO "); Serial.println(LORA_CS);
  Serial.print("  RST:  GPIO "); Serial.println(LORA_RST);
  Serial.print("  DIO0: GPIO "); Serial.println(LORA_DIO0);
  Serial.println();
  
  LoRa.setPins(LORA_CS, LORA_RST, LORA_DIO0);
  
  Serial.println("Attempting LoRa.begin(915E6)...");
  if (!LoRa.begin(915E6)) {
    Serial.println("✗✗✗ Starting LoRa FAILED! ✗✗✗");
    Serial.println("\nPossible issues:");
    Serial.println("1. Check LoRa module wiring");
    Serial.println("2. Verify pin definitions match your board");
    Serial.println("3. Ensure LoRa module has power (3.3V)");
    Serial.println("4. Check antenna is connected");
    Serial.println("========================================\n");
    return false;
  }
  
  Serial.println("✓✓✓ LoRa initialized successfully! ✓✓✓");
  loraActive = true;
  
  Serial.println("Creating LoRa hub...");
  delay(100);
  
  createHub("Greenhouse", "Temperature,Humidity,Lux,Distance", "1,2,1,2");
  
  Serial.println("========================================\n");
  return true;
}

void createHub(const char* hubName, const char* sensorNames, const char* types) {
  if (!loraActive) {
    Serial.println("ERROR: Cannot create hub - LoRa not active!");
    return;
  }
  
  if (!hubName || !sensorNames || !types) {
    Serial.println("ERROR: Invalid parameters for hub creation");
    return;
  }
  
  if (!LoRa.beginPacket()) {
    Serial.println("ERROR: Failed to begin LoRa packet");
    return;
  }
  
  LoRa.print("    ");
  LoRa.print("CH");
  LoRa.print(">");
  LoRa.print(hubName);
  LoRa.print(":");
  LoRa.print(sensorNames);
  LoRa.print(":");
  LoRa.print(types);
  
  if (!LoRa.endPacket()) {
    Serial.println("ERROR: Failed to send LoRa packet");
    return;
  }
  
  Serial.print("LoRa: Hub created - ");
  Serial.println(hubName);
  Serial.print("  Sensors: ");
  Serial.println(sensorNames);
  Serial.print("  Types: ");
  Serial.println(types);
}

void pushAllData(const char* hubName) {
  if (!loraActive) {
    Serial.println("ERROR: Cannot send data - LoRa not active!");
    return;
  }
  
  if (!hubName) {
    Serial.println("ERROR: Invalid hub name");
    return;
  }
  
  SensorData& sensors = getSensorData();
  
  Serial.println("=== Sensor Readings ===");
  Serial.print("Temperature: ");
  Serial.print(sensors.temperature);
  Serial.println("°C");
  Serial.print("Humidity: ");
  Serial.print(sensors.humidity, 1);
  Serial.println("%");
  Serial.print("Lux: ");
  Serial.println(sensors.lux);
  Serial.print("Distance: ");
  Serial.print(sensors.distance, 2);
  Serial.println(" in");
  
  if (!LoRa.beginPacket()) {
    Serial.println("ERROR: Failed to begin LoRa packet");
    return;
  }
  
  LoRa.print("    ");
  LoRa.print("PD");
  LoRa.print(">");
  LoRa.print(hubName);
  LoRa.print(":");
  LoRa.print(sensors.temperature);
  LoRa.print(",");
  LoRa.print(sensors.humidity, 1);
  LoRa.print(",");
  LoRa.print(sensors.lux);
  LoRa.print(",");
  LoRa.print(sensors.distance, 2);
  LoRa.print(",");
  
  if (!LoRa.endPacket()) {
    Serial.println("ERROR: Failed to send LoRa packet");
    return;
  }
  
  Serial.println("  -> LoRa: Sent all sensor data!");
  Serial.println("=======================\n");
  
  sensors.lastLoRaTransmit = millis();
}

bool isLoRaActive() {
  return loraActive;
}