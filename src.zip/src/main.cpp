#include <Arduino.h>
#include "Sensors.h"
#include "LoRaLink.h"
#include "NowLink.h"
#include "Config.h"
#include "Commands.h"

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("\n=== ESP32 Multi-Sensor Hub with ESP-NOW + LoRa ===");
  Serial.println("Sensors: Temperature, Humidity, Light, Ultrasonic Distance\n");

  // Initialize sensors
  initializeSensors();
  
  // Initialize configuration
  initializeConfig();
  
  // Initialize LoRa
  if (!initializeLoRa()) {
    Serial.println("⚠️  WARNING: LoRa initialization failed!");
    Serial.println("⚠️  Sensors will read but no LoRa transmission!");
    Serial.println("⚠️  Type 'lora' to retry.\n");
  }

  // Initialize ESP-NOW
  initializeNowFromEEPROM();
  
  // Print help
  printStartupInfo();
  
  // Read initial sensor values
  readEnvironmentalSensors();
}

void loop() {
  unsigned long currentTime = millis();

  // Read environmental sensors periodically
  if (currentTime - getSensorData().lastEnvironmentalUpdate >= ENVIRONMENTAL_SENSOR_INTERVAL) {
    readEnvironmentalSensors();
  }

  // Handle incoming ESP-NOW messages
  handleNowMessages(currentTime);

  // Send LoRa data periodically
  if (isLoRaActive() && currentTime - getSensorData().lastLoRaTransmit >= LORA_TRANSMIT_INTERVAL) {
    pushAllData("Greenhouse");
  }

  // Handle serial commands
  handleSerialCommands();

  delay(1);
}